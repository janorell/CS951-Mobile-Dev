package com.example.c2_p23;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private Button button;
    private TextView trafficlight;
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);
        trafficlight = (TextView) findViewById(R.id.trafficlight);

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                counter++;
                int mod = counter % 3;
                if (mod == 0){
                    trafficlight.setBackgroundColor(Color.RED);
                }
                else if (mod == 1){
                    trafficlight.setBackgroundColor(Color.GREEN);
                }
                else{
                    trafficlight.setBackgroundColor(Color.YELLOW);
                }
            }
        });
    }



}