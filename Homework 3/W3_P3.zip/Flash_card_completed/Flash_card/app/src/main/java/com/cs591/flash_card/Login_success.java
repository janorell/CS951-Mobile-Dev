package com.cs591.flash_card;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;


public class Login_success extends AppCompatActivity {
    // initializing all the components in the layout
    RadioGroup radioGroup;
    Button submit;
    EditText txt_Ans;
    TextView tv_num1;
    TextView tv_num2;
    TextView operator;
    String current_op = "+";
    int score;
    int stage;
    int ans;
    int num1;
    int num2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        radioGroup = findViewById(R.id.radiogroup);
        submit = findViewById(R.id.btn_sumbit);
        tv_num1 = findViewById(R.id.num1);
        tv_num2 = findViewById(R.id.num2);
        operator = findViewById(R.id.operator);
        txt_Ans = findViewById(R.id.txt_answer);

        radioGroup.check(R.id.rad_add);

        //onclick submit
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if it is the last stage
                if (stage == 9) {
                    stage++;
                    checkAns();
                    end_game();
                } else {
                    stage++;
                    checkAns();
                    nextQuestion();
                    txt_Ans.setText("");
                }
            }
        });

        if (savedInstanceState == null) {
            //Event handler for radiobutton 'onChange'
            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch (checkedId) {
                        case R.id.rad_add:
                            start_game_add();
                            break;
                        case R.id.rad_sub:
                            start_game_sub();
                            break;

                    }
                }
            });
            Bundle bundle = getIntent().getExtras();
            String username = bundle.getString("user");
            Toast.makeText(this, "Welcome! " + username, Toast.LENGTH_SHORT).show();
        }
    }

    //function for end of the game
    private void end_game() {
        Toast.makeText(Login_success.this, "Game Over! Score: " + score + "/" + stage, Toast.LENGTH_SHORT).show();
        score = 0;
        stage = 0;
        operator.setText(":)");
        tv_num1.setText("");
        tv_num2.setText("");
    }

    //nextQuestion depending on radio button
    private void nextQuestion() {
        if (current_op.equals("+")) {
            question_add();

        } else {
            question_sub();
        }
    }

    //function for checking answers
    private void checkAns() {
        try {
            if (ans == Integer.parseInt(txt_Ans.getText().toString())) {
                score++;
                Toast.makeText(this, "Correct! Current Score: " + score + "/" + stage, Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(this, "Wrong! Current Score: " + score + "/" + stage, Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            Toast.makeText(this, e + "", Toast.LENGTH_SHORT).show();
        }

    }

    //event on change of radio button
    private void start_game_add() {
        current_op = "+";
        operator.setText("+");
        question_add();
    }

    //event on change of radio button
    private void start_game_sub() {
        current_op = "-";
        operator.setText("-");
        question_sub();

    }

    //Create new questions for addition
    private void question_add() {
        Random random = new Random();
        operator.setText("+");
        num1 = random.nextInt(10);
        num2 = random.nextInt(10);
        ans = num1 + num2;
        tv_num1.setText(String.valueOf(num1));
        tv_num2.setText(String.valueOf(num2));


    }

    //Create new questions for subtraction
    private void question_sub() {
        Random random = new Random();
        operator.setText("-");
        num1 = random.nextInt(10);
        num2 = random.nextInt(10);
        while (num1 < num2) {
            num2 = random.nextInt(10);
        }
        ans = num1 - num2;

        tv_num1.setText(String.valueOf(num1));
        tv_num2.setText(String.valueOf(num2));
    }

    //Save stage and score upon rotation
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt("num1", num1);
        outState.putInt("num2", num2);
        outState.putInt("ans", ans);
        outState.putInt("stage", stage);
        outState.putInt("score", score);
        super.onSaveInstanceState(outState);

    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        score = savedInstanceState.getInt("score");
        stage = savedInstanceState.getInt("stage");
        num1 = savedInstanceState.getInt("num1");
        num2 = savedInstanceState.getInt("num2");
        ans = savedInstanceState.getInt("ans");
        tv_num1.setText(String.valueOf(num1));
        tv_num2.setText(String.valueOf(num2));
        Toast.makeText(this, "State Reloaded! " + score + "/" + stage, Toast.LENGTH_SHORT).show();
        super.onRestoreInstanceState(savedInstanceState);
    }
}
