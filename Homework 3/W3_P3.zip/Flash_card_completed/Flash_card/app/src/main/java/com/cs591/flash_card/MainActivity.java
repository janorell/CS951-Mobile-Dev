package com.cs591.flash_card;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button login;
    // hardcoded user and password
    private String user ="test";
    private String pass ="1234";
    private EditText userinput;
    private EditText passinput;
    // 2 inputs username and password EditText



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userinput = (EditText) findViewById(R.id.username);
        passinput = (EditText) findViewById(R.id.password);
        login  = (Button) findViewById(R.id.btn_login);
        // login event
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Auth_login(userinput.getText().toString(),passinput.getText().toString());
            }

        });
    }
        //Login Function
    private void Auth_login(String user,String pass) {
        if(user.equals("test") && pass.equals("1234")) {
            Intent intent = new Intent(this, Login_success.class);
            //creating bundle to send it over to other activity
            String getuser = user;
            Bundle bundle = new Bundle();
            bundle.putString("user", getuser);
            intent.putExtras(bundle);
            startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(), "Wrong Username or Password", Toast.LENGTH_SHORT).show();
        }
    }
}
